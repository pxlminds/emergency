export const environment = {
  production: true,
  apiUrl: 'http://54.205.237.196:8507/api/v1'
};
