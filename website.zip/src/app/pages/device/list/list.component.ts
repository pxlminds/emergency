import { Component, OnInit } from '@angular/core';
import { environment } from '../../../../environments/environment';
import { HttpClient, HttpHeaders,HttpParams, HttpParamsOptions  } from '@angular/common/http';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss']
})
export class ListComponent implements OnInit {
 deviceDataSet : any = {data: []};
  constructor(private http:HttpClient) { }
 localvar: any;
 tokens :any;
 token:any;



  ngOnInit(): void {
    this.loadDevice();
  }
  loadDevice(page = 0){
      let token =JSON.parse(localStorage.getItem("token"));
      this.token = "Bearer " + this.token
      let headers = new HttpHeaders()
      .set('Content-Type', 'application/json')
      .set('Authorization', token)
      .set('Access-Control-Allow-Origin', 'true');
      
      console.log(headers); 
      const myObject: any = { userId: '6', pageNumber: '1', pageSize: '10'};
      const httpParams: HttpParamsOptions = { fromObject: myObject } as HttpParamsOptions;
      const options = { params: new HttpParams(httpParams), headers: headers };
      this.http.get<any>(`${environment.apiUrl}/device/list`, options)
        .subscribe( result => {this.deviceDataSet = result; },
          error => { console.log(error) },
          () => {            
          }
          );


  /*     
        let headers_object = new HttpHeaders({
        'Content-Type': 'application/json',
       

       });      
        const httpOptions = {
          headers: headers_object,
          withCredentials: true,
        };
         let params = new HttpParams().set('userId',6);
        
        this.http.get(, httpOptions).subscribe(
          result => {this.deviceDataSet = result; },
          error => { console.log(error) },
          () => {
            
          }
        );  */
  }
}


interface Sidebar {
    _id: string;
    content: string;
}