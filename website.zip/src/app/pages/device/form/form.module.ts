import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormComponent } from './form.component';
import { HeaderModule } from '../../elements/header/header.module';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';


@NgModule({
  declarations: [
    FormComponent
  ],
  imports: [
    CommonModule,HeaderModule, RouterModule, HttpClientModule,
    ReactiveFormsModule,
    FormsModule
  ]
})
export class FormModule { }
