export class User {
    id: number;
    emailID: string;
    password: string;
    firstName: string;
    lastName: string;
    token?: string;
}